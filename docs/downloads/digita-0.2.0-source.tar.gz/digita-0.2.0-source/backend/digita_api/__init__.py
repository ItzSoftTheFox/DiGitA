"""DiGitA REST API."""
