# Detailed development and pilot guide

For a quick start and repository navigation, see the [project README](../README.md)
and [code map](codebase.md). Run the commands below from the repository root unless
another directory is specified. Dated validation results are historical records.

![DiGitA — A quieter workspace. Better teamwork.](images/banner.svg)

<p align="center">
  A desktop home for your team's work — before the next push.<br />
  Live Git activity, early conflict warnings, and a shared space to focus.
</p>

<p align="center">
  <a href="#screenshots">Screenshots</a> ·
  <a href="#getting-started">Get started</a> ·
  <a href="#roadmap">Roadmap</a> ·
  <a href="../backend/README.md">Backend docs</a>
</p>

<p align="center">
  <code>Tauri 2</code> &nbsp; <code>React</code> &nbsp; <code>Rust</code> &nbsp;
  <code>FastAPI</code> &nbsp; <code>PostgreSQL</code>
</p>

---

| See work as it happens                                                         | Catch overlaps early                                              | Find your focus                                             |
| ------------------------------------------------------------------------------ | ----------------------------------------------------------------- | ----------------------------------------------------------- |
| Share permitted Git metadata with your room, while code stays on your machine. | See when teammates change the same file, before a commit or push. | Use a shared room with a live timeline and optional system notifications. |

## Screenshots

Actual application UI, captured in the browser with demo/test accounts and
repositories. The interface defaults to English; Czech is available in Settings → Language. Click any image for full size.

### Your local workspace

Branch, latest commit, and working-tree changes in one view, with search and
staged/unstaged filters.

[![DiGitA local workspace showing a branch, commit, and filtered Git changes](images/workspace.png)](images/workspace.png)

<details>
<summary><strong>Explore team rooms and Conflict Radar</strong></summary>

### Your team's spaces

Create a team, join through an invitation, and pick up work in a project room.

[![Team dashboard with room creation, invitations, refresh, and a project room](images/dashboard.png)](images/dashboard.png)

### A heads-up before the merge

Conflict Radar identifies overlapping file paths and the people working on them.
It highlights possible risk; it does not claim a Git merge conflict is certain.

[![Conflict Radar showing Anna and Petr changing the same file](images/conflict-radar.png)](images/conflict-radar.png)

</details>

## Project status

**0.2.0 release candidate. Current distribution priority: Arch Linux x86_64.**

The desktop includes registration/login, a dashboard of teams and rooms, invitations, online presence, optional Git metadata sharing, and a live timeline. The local Git workspace remains available without signing in. The native application passes `cargo check`, builds, and displays its interface on Arch Linux with Wayland.

FastAPI provides accounts, team permissions, single-use invitations, and authenticated WebSocket rooms. PostgreSQL stores account/team data; active presence, conflict warnings, and the last 100 room events live in server memory. Validation is described below.

English is the default application language; Czech is available in **Settings → Language**. An Arch pilot package and a separate
HTML + Tailwind download website are prepared. Phase 7 implementation and automated validation are complete; native two-device
and clean-environment package validation remain open. This is not a published release.
See the [validation index](README.md#design-and-validation) and
[remaining native checklist](history/validation-0.2.0-phase-1.md).

## Current features

- Register and log in, optionally remembering the desktop session in the OS credential store.
- Create teams and rooms, invite colleagues, and switch rooms from the main dashboard.
- See online room members, their permitted Git metadata, and a live activity timeline.
- Enable sharing explicitly, with independent controls for branch names, file names, and commit messages.
- Reconnect after network interruptions and receive the room's current state.
- Detect shared file paths changed by multiple online members, with live warning removal and optional desktop notifications.
- Select a local Git repository through a native directory picker and disconnect it at any time.
- View the current branch, latest commit, changed files and local upstream ahead/behind.
- Distinguish staged and unstaged changes, search paths, and filter the file list.
- Refresh manually or automatically two seconds after the previous read completes.
- Show no upstream, no commits, detached HEAD and merge/rebase/cherry-pick in progress.
- Copy relative paths/full commit hashes and filter staged/unstaged/untracked/conflicted files.
- Bound Git reads; label last-known data stale after errors and withdraw sharing.
- Explore an explicitly labeled browser demo without connecting a repository.

## Roadmap

### Desktop navigation

After login, the left sidebar lists all joined teams. Selecting one opens its
rooms and administration; the active team is marked. Mouse and keyboard switching
preserve draft guards and withdraw previous room sharing. The saved signed-in
profile and Settings remain at bottom left, including in local mode. The dashboard
offers team/room creation and invitation acceptance according to permissions.

The local Git overview is part of the selected room's workspace,
alongside members, activity and Conflict Radar. Users can
return to the dashboard to switch rooms. In this UX, a "server" means a team space;
selecting multiple backend hosts is a separate future feature.

The original prototype phases delivered the features above. The next milestone,
**0.2.0**, is organized into seven phases:

1. Verify 0.1.0, fix blocking defects, and update documentation.
2. Improve first launch, connection states, and error recovery.
3. Separate Settings from the dashboard and refine navigation/UI.
4. Remember local projects and preferences without restoring sharing consent.
5. Add team administration and account personalization.
6. Improve local Git status and bound Git process time/output.
7. Validate the complete pilot and packaging on Arch Linux.

The Phase 5 follow-up adds owner-only team deletion, the profile/Settings footer
and sidebar team switching. Phase 6 adds explicit sharing choices when connecting
a room repository. Account deletion remains deferred until owned-team behavior
and retention are defined. Ownership transfer is outside this milestone.

Windows/macOS and broader Linux releases are tentatively deferred to **0.5.0**.
Profile customization, team administration, dedicated Settings and remembered local
projects/preferences are implemented. Chat, voice, the service-wide admin dashboard, automatic updates, and Git
write operations are outside the 0.2.0 scope.

### MVP target

Two users should be able to join the same room, connect separate working copies of the same repository, see each other's branch and local activity, receive warnings when they edit the same file. Each user must be able to disable file-name sharing.

Conflict Radar indicates potential overlap; it does not guarantee that Git will produce a merge conflict or resolve conflicts automatically.

## Technology

| Area               | Technology                              | Status                                           |
| ------------------ | --------------------------------------- | ------------------------------------------------ |
| Desktop shell      | Tauri 2 and Rust                        | Build and window startup verified on Arch Linux  |
| Interface          | React, TypeScript, Vite, Lucide         | Implemented                                      |
| Git integration    | Git CLI through a standalone Rust crate | Implemented; bounded read-only local status      |
| Frontend testing   | Vitest and Testing Library              | Implemented                                      |
| Browser testing    | Playwright and Chromium                 | Implemented                                      |
| Backend            | Python and FastAPI                      | Implemented; includes conflict lifecycle tests   |
| Database           | PostgreSQL and Alembic                  | Implemented; migrations verified                 |
| Realtime transport | WebSocket                               | Implemented; authenticated room connections      |
| Local persistence  | Validated JSON in native app data       | Implemented; browser preview uses web storage    |
| Infrastructure     | Docker Compose and GitHub Actions       | Local PostgreSQL Compose; hosted workflows paused |

## How the pieces connect

```mermaid
flowchart LR
    A[Local Git copy A] --> B[Desktop client A]
    C[Local Git copy B] --> D[Desktop client B]
    B <-->|HTTP / WebSocket metadata| E[FastAPI — one process]
    D <-->|HTTP / WebSocket metadata| E
    E --> F[(PostgreSQL: accounts, teams, rooms)]
    E --> G[Memory: presence, radar, timeline]
```

Each member keeps their own repository and uses their normal Git remote to
exchange code. DiGitA does not upload or synchronize repository contents.
The HTML + Tailwind portfolio/download website is separate from the collaboration
API; that API must remain reachable while people use shared rooms.

## Getting started

### Requirements

- Node.js 22 or newer and npm.
- Git installed and available on `PATH`.
- Rust and Cargo for the desktop application and Git tests.
- Python 3.12+, uv, and Docker Compose only when running your own local backend.
- The [Tauri system prerequisites](https://v2.tauri.app/start/prerequisites/) for your operating system.

On Arch Linux, install the native dependencies with:

```sh
sudo pacman -S --needed rust webkit2gtk-4.1 base-devel librsvg openssl curl wget file xdotool libappindicator-gtk3
```

### Desktop application

From the project root:

```sh
npm ci
npm run tauri dev
```

By default the client uses the local API at `http://127.0.0.1:8000`; start it below
in a separate terminal. To use the existing pilot instead, set the root `.env` to
`VITE_API_URL=https://digita-hvse.onrender.com` and restart the desktop dev command.
The development CSP already permits this pilot. You then need no local Python,
PostgreSQL, or backend process. Pilot registration may be closed; use an existing
pilot account. A team invitation does not create an account.

For a downloadable build connected to the pilot, follow the
[Arch package guide](arch-linux.md); its script sets both the embedded API URL
and the production CSP. A plain `tauri build` uses the base local-only CSP.

Register or log in to your selected backend. Create a team
and room, enter it, and choose **Connect repository**. Each
member selects their own working copy and confirms it belongs to the room before
enabling sharing. A room represents one logical project; remote URLs are not
automatically matched. Change the sharing checkboxes to permit individual fields.

For offline use, choose **Local mode** on the login screen, including while a
server request is pending. First launch shows a short skippable introduction;
reopen it under **Settings → About → Quick start**.

Requests show a slow-server hint after eight seconds. Rate-limit responses show
a countdown. Expired sessions return to sign-in; failed saved-session restoration
can be retried. Errors do not display arbitrary backend or credential-store details.
If a creation request loses its response, refresh the rooms and check the result
before explicitly allowing a new request. Requests are not automatically replayed;
a lost invitation code cannot be recovered and another invitation consumes quota.
Use **Sign in online** in the workspace header to return to login, or
**Back to team space** if you are already signed in. On the dashboard,
**Refresh rooms** reloads your teams, rooms, and permissions.
Selecting a repository subdirectory also works. Edit a file in your usual editor
and the overview refreshes automatically. Changing rooms or repositories resets
sharing consent. Linux session persistence requires an unlocked Secret Service
keyring; leave **Remember sign-in in the system credential store** unchecked to use an in-memory session.

### Browser preview

```sh
npm ci
npm run dev
```

Open `http://127.0.0.1:1420`. Login and rooms use the running backend. For the
static Git demo, choose **Local mode**, then **View demo**.
Access to a real local repository requires the desktop application. The separate
public website lives in `website/` and builds into `docs/` for GitHub Pages.

Stop the standalone preview server before running `npm run tauri dev`; both use port 1420.

### Background music removal

Phase 7 removes bundled audio, playback code and WebSocket commands, and volume
preferences. System notifications remain available under Settings → Notifications.
Preferences v2 accepts valid v1 data, drops volume and preserves projects, room
folders and notification intent. The storage filename/key stays the same.

### Conflict Radar

Open the same room using two different accounts and connect each account's local
working copy. Enable Git sharing in the room and **Settings → Privacy → File names** on both clients. Change the
same relative path in both working copies: a nonmodal Conflict Radar panel slides
in from the left after the next Git refresh and lists the path and members. No commit or push is required. Remove one change or
disable file sharing: the warning disappears. Leaving, revocation, and network
loss also remove the affected live state; a disappeared warning does not prove
that a merge conflict was resolved.

Use **Conflict Radar** in the room header to open or close the panel at any time,
including when no overlap is detected. The close button or Escape also closes it.
Closing a warning keeps the panel dismissed through unrelated updates and your
connection recovery; a new overlap opens it again. Automatic opening preserves
keyboard focus, and reduced-motion preferences disable the slide animation.

Comparison uses exact, case-sensitive Git paths across all branches in one room.
Renames share both old and new paths, without increasing the changed-file count.
Hidden lists and oversized payloads cannot participate; the UI shows how many
online members are sharing comparable lists. No code, diff, PR analysis, or
ahead/behind analysis is involved.

Warnings are live room state, not database records. Historical `conflict.detected`
and `conflict.resolved` events contain no paths or participant lists. Each event
type is batched and limited to once per 30 seconds per room; the live warning list
always updates immediately, even when a timeline event is suppressed.

**Settings → Audio and notifications → Enable system notifications** enables native
notifications on this device after an OS permission check. Notifications concern only the current user's
new overlaps, contain no file/member/project names, wait 1.5 seconds to group bursts,
and occur at most once per 30 seconds. Resolved or withdrawn warnings cancel pending
notifications. Reconnection establishes a new baseline without replaying existing
warnings. In-app warnings remain available when notifications are disabled or fail.

Native notification delivery depends on the OS notification service. Windows
release validation should use an installed application; development notifications
can use PowerShell branding. See the [Tauri notification plugin documentation](https://v2.tauri.app/plugin/notification/).
Real OS delivery on Linux and an installed Windows build remains a manual release
check; automated frontend tests mock the notification boundary.

### Backend and accounts

With Python 3.12+, uv, and Docker Compose installed, run from the project root:

```sh
docker compose up -d --wait db
cd backend
uv sync --locked
# First setup only: copy the example if backend/.env does not already exist.
cp .env.example .env
uv run alembic upgrade head
uv run uvicorn digita_api.main:create_app --factory --host 127.0.0.1 --port 8000 --no-proxy-headers --ws-max-size 65536
```

Check `http://127.0.0.1:8000/health` for `{"status":"ok"}`. The root `/` and
`/favicon.ico` have no handlers; their 404 responses are expected.
Open `http://127.0.0.1:8000/docs` to register, log in, create a team and room, and
invite a second account. See [backend setup and API workflow](../backend/README.md)
for permissions, configuration, security choices, and PostgreSQL test instructions.
From `backend/`, run `uv run pytest -q` for the isolated SQLite test suite.

### Configuration files

| Location                                         | Purpose                                                                                                                   |
| ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------- |
| Root `.env` (optional; copy root `.env.example`) | `VITE_API_URL`, default `http://127.0.0.1:8000`; restart Vite or rebuild the desktop after changing it                    |
| `backend/.env` (copy `backend/.env.example`)     | Database connection, session/invitation lifetimes, rate limits, and trusted origins; run backend commands from `backend/` |

`VITE_*` values are public frontend build configuration: never put passwords or
private API keys there. Real `.env` files, private keys, local databases, and
backups are ignored; example files intentionally remain tracked. The Compose
password is a public local-development default, not a production secret.
Ignoring a path does not remove an already tracked file or secrets in Git history.

An API on another host requires HTTPS/WSS, permitted frontend origins on the
backend, and matching `connect-src` entries in `src-tauri/tauri.conf.json`.
For local VM testing, use the tunnel below and retain the default loopback URL.

### Windows VM test with a Linux backend

Use two different accounts and two separate working copies of the same project.
A VM on the same computer is sufficient for this development check.

1. Start PostgreSQL and the backend on Linux using the commands above. Ensure
   the Linux host's SSH server is running and reachable from the VM.
2. In Windows **PowerShell**, replace `LINUX_HOST` with the host's reachable IP
   or hostname, and `LINUX_USER` with its SSH account:

   ```powershell
   Test-NetConnection LINUX_HOST -Port 22
   ssh -N -o ExitOnForwardFailure=yes -L 127.0.0.1:8000:127.0.0.1:8000 LINUX_USER@LINUX_HOST
   ```

   On first connection, verify the displayed host-key fingerprint against the
   Linux host before accepting it. Keep this terminal open; a quiet tunnel is normal.

3. In another PowerShell terminal, check the forwarded backend:

   ```powershell
   Invoke-RestMethod http://127.0.0.1:8000/health
   ```

4. In the Windows project checkout, with Node/npm, Git, Rust's MSVC toolchain,
   the C++ build tools, and WebView2 installed per the Tauri prerequisites:

   ```powershell
   npm.cmd ci
   npm.cmd run tauri dev
   ```

   No second database or backend is needed in the VM. Keep `VITE_API_URL` at
   `http://127.0.0.1:8000` and ensure Windows port 8000 is free before opening the tunnel.

5. Create a team and room on Linux, invite the Windows account, and enter the
   same room. Connect each local repository and enable the fields to share.
   Check live changes, the Conflict Radar procedure above, sharing withdrawal
   and membership removal on both clients. Interrupt/reopen the tunnel to check reconnection.

### Troubleshooting

| Symptom                                                   | Check                                                                                                                                                        |
| --------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Login cannot be saved in the system store                 | On Linux, an unlocked Secret Service keyring must be available in the desktop session. Leave remember-login unchecked to continue with an in-memory session. |
| `beforeDevCommand` exits with a non-zero status           | Read the earlier Vite/npm error; this final Tauri line is only a summary. Run `npm run dev` alone to see the cause, then stop it before starting Tauri.      |
| Port 1420 is already in use                               | Stop the standalone Vite preview or the other development app using it.                                                                                      |
| Windows `EBUSY` under `src-tauri/target`                  | Use the current `vite.config.ts`, which excludes `src-tauri` from Vite watching; restart the development app.                                                |
| `Test-NetConnection` is not recognized                    | Run it in PowerShell, not Command Prompt.                                                                                                                    |
| SSH closes or `/health` is unreachable through the tunnel | Check the host address, SSH authentication/server, local port availability, and whether the Linux backend is running.                                        |
| Room state vanishes after everyone leaves                 | Expected: live room state is held in memory, while account/team/room records remain in PostgreSQL.                                                           |

## Development and testing

```sh
# Run component and hook tests
npm test

# Check TypeScript and build the frontend
npm run build

# Test Git behavior using temporary repositories
npm run test:git

# Check the native desktop application
cargo check --locked --manifest-path src-tauri/Cargo.toml

# Install the test browser and run browser tests
npx playwright install chromium
npm run test:e2e

# Format frontend files and configuration
npm run format
```

Run `uv sync --locked` in `backend/` before browser tests. Playwright starts an
isolated API with a temporary SQLite database on port 8001 and a frontend on 1421.
It tests the local demo and two accounts creating/joining a room, live metadata,
privacy changes, a changed commit, Conflict Radar, preference migration,
dashboard refresh, navigation, diagnostics privacy and network recovery. Native
Git reads, the directory picker, and session-store calls are mocked; HTTP,
and WebSockets are real. OS notifications are tested separately
with mocks, not delivered by these browser tests. Screenshots are in
the ignored `artifacts/` directory.

Rust dependency versions are recorded in `src-tauri/Cargo.lock` and `crates/git-presence/Cargo.lock` for reproducible application builds and Git tests.

### Current validation

See [Phase 7 evidence](history/validation-0.2.0-phase-7.md) and the
[0.2.0 exit checklist](checklist-0.2.0.md)
and the remaining [native pilot checklist](history/validation-0.2.0-phase-1.md).
The dated results below are historical and do not validate later changes.

Earlier native builds, window rendering and repository selection were checked on
Arch Linux. Automated checks mock OS boundaries; native keyring,
notifications, suspend/resume and two-device validation remain on the checklist.
Historical Phase 2/3/4 evidence is consolidated in
[the earlier milestones](history/milestones-0.2.0.md).

## Project structure

```text
src/                    React interface; see codebase.md for components/hooks/lib
src-tauri/              Tauri application, configuration, and icons
scripts/                Cleanup and release tooling
crates/git-presence/    Git inspection library and Rust tests
e2e/                    Playwright browser tests
docs/                   Guides, history and published website; see README.md
backend/digita_api/     FastAPI accounts, teams, rooms, invitations, and WebSockets
backend/migrations/     Alembic database migrations
backend/tests/          API, WebSocket, radar, protocol rejection and migration tests
compose.yaml            Local PostgreSQL development database
```

## Privacy and scope

Local mode requires no account and sends no repository data. Room mode announces
online presence; Git sharing remains off until enabled. Recent repository paths
and optional room-folder associations are saved only on this device. Restoring a
folder never restores sharing consent. DiGitA does not perform Git write operations.

When sharing is enabled, the client sends the room/project ID, changed-file count,
commit hash, and only the optional metadata permitted by the user. It never sends
source code, diffs, absolute local paths, or commit authors. Hidden fields are also
removed on the server. The timeline contains generic event descriptions, without
file names, branch names, or commit messages. Session tokens are kept in memory
or the OS credential store; web storage contains a remember-login flag, the
language preference and an intro-dismissal flag, never tokens. Desktop project
and notification preferences live in `local-preferences.json` in the application's data
directory. Browser preview stores its permitted preferences in web storage and
cannot read remembered folders. Neither store contains sharing consent,
OS notification permission or credentials.

Team menus expose member lists, role changes, member removal/leaving, owner-only
team deletion and active invitation creation/revocation. Owners manage
nonowner roles and remove nonowners; admins create/revoke invitations; nonowners
may leave. The owner cannot leave or be removed. Removed members lose live room
access immediately. Deleting a team confirms permanent removal of its rooms,
memberships and invitations; affected clients return to a refreshed team or
empty state. Accounts and other teams survive. Invitation listings never reveal
a code or token hash.

The MVP does not include a code editor, shared terminal, live collaborative editing, voice/video calls, automatic conflict resolution, or commercial music streaming.

## Licensing

DiGitA is licensed under [GPL-3.0-only](../LICENSE), selected by the project owner
on 2026-10-03. Distributed binaries must have matching corresponding source.
Third-party dependencies retain their own licenses. The package includes LICENSE;
public distribution requires publishing the exact source used to build it.

## Known limitations

- Native validation has been performed on Arch Linux only; other operating systems remain unverified.
- Git reads are serialized across project switches, with five seconds per command,
  fifteen seconds per snapshot and 8 MiB combined stdout/stderr per command.
  Limit violations terminate/reap Git and return an error; lists are never truncated.
  Unix terminates the process group; Windows currently terminates only the direct
  child and needs separate native validation.
- Ahead/behind uses local upstream references and may be stale without fetch.
  DiGitA never fetches; missing upstream/tracking data shows no counts.
- Invalid UTF-8 Git paths/status/commit metadata reject the read. Last-known
  state remains explicitly stale and is not shared.
- The base Tauri configuration disables bundling; the Arch script and release override enable distribution. The Arch pilot still needs clean-install validation.
- Radar compares file paths only and cannot detect line-level or committed-branch overlaps.
- Run one backend worker: room state and timeline are in memory and disappear after the last member leaves or the server restarts. A room supports up to 32 online users, with one active connection per user.
- Git file lists above 500 entries or the payload budget share counts only. Project identity is confirmed by the user, not inferred from Git remote addresses.
- A changed HEAD is shown as a changed last commit; it does not prove a new commit was created rather than checked out.
- Local development and Render/Neon pilot deployment configurations exist. Live provider configuration has not been re-audited in this phase; multi-worker operation is unsupported. See the backend README for current limits.

### Pilot security

The [security review and deployment requirements](security-review.md)
record code review, regression tests, and dependency checks before provider setup.
Automated checks are defined in `.github/workflows/security.yml`, currently paused.

### Desktop distribution

DiGitA is distributed as a React + Tauri desktop app. The public website provides
product information and downloads; the backend provides accounts and collaboration.
See [desktop-release.md](desktop-release.md) for installer preparation,
GitHub Releases, and API deployment.

### Arch Linux package

The current priority is **Arch Linux x86_64**. Running
`bash scripts/build-arch.sh` locally creates a pacman package without GitHub Actions.
See [build, installation, and distribution](arch-linux.md).

### Product website / GitHub Pages

A separate HTML + Tailwind website includes app previews, FAQ, and the Arch pilot
download. Sources live in `website/`; built output lives in `docs/`.
See [local preview, editing, and GitHub Pages setup](../website/README.md).

### Settings and navigation

The sidebar Settings button is available from sign-in, the dashboard, local work,
and rooms. Settings has Account and profile, Projects, Privacy, Notifications, Language, and About sections. Close it or press Escape to return
without losing room connection, repository filters, or sharing consent.
Sharing status and Stop sharing remain available in Settings and beside the room
repository controls. Selecting a folder still opens explicit sharing choices.
Language and personal preferences apply immediately and report storage failures.
**Account and profile** edits the display name (1–80 characters), bundled avatar,
background color and custom status (up to 120 characters). Teammates see these
fields; email stays private. Custom status is separate from online presence.
Edits use an explicit Save; failures preserve the draft, and leaving unsaved
changes offers **Keep editing** or **Discard**. Saves update live teammates
without reconnecting the room or changing Git sharing consent. Reset avatar and
Clear status affect the draft until saved. A save with an unknown outcome requires
refreshing the profile and reviewing the result before another request.

**Settings → Projects** lists up to 20 recent repositories with open/remove
controls. The local workspace restores its last selected repository. A room
restores a folder only when **Remember this folder for this room** was explicitly
selected; the association is scoped to the backend, account and room. Unbound
rooms start without a repository. Switching or removing the active project
withdraws Git sharing and requires fresh consent. Connecting/selecting/restoring
a valid room repository opens sharing choices for branch name, file names and
commit message. Confirm that the repository belongs to the room, then select
**Start sharing**. Cancelling keeps sharing off. Change count and commit hash are
always included after consent; upstream/ahead/behind/operation stay local.
Local mode does not open a sharing dialog. Missing or moved folders offer
**Reassign folder**. Only the active workspace polls Git; late results from a
previous selection are ignored.

Notification intent is saved locally. Restoring it never requests OS permission. Remembered notifications
remain inactive without existing OS permission; use **Enable system
notifications** to review permission. **Clear project and notification preferences**
confirms before removing remembered folders/associations and resetting
notification intent. Language and sign-in are kept. Failed writes preserve
the in-memory choices and offer a retry; failed loads preserve saved data until
an explicit clear. See [the earlier milestones](history/milestones-0.2.0.md)
for the automated evidence and remaining desktop checks.

Use a team's **Team menu** for administration. Owners can change nonowner roles
and remove members. Owners/admins can create and revoke active invitations;
members see their roster and can leave. Removal, leaving and revocation ask for
confirmation. **Refresh team** rechecks membership and permissions. Invitation
codes are shown when created and cannot be recovered from the listing. Creation
drafts survive Settings and failed requests; switching/cancelling filled forms
or leaving for local mode asks before discarding. See the
[phase 5 validation](history/validation-0.2.0-phase-5.md).

### Language policy

Write project Markdown, new UI source strings, and website copy in English.
The app starts in English regardless of the operating-system language. **Settings →
Language → Čeština** switches the interface immediately and saves the choice on
this device. It does not sign out, reconnect rooms, or restore sharing consent.
Maintain Czech translations in `src/i18n/translations.cs.json`; use `t()` for UI text
and `useTranslation()` in components that must update when the language changes.
User names, repository paths, branch names, and commit contents are not translated.
Backend/native messages use English; known messages are localized by the client.
The website and documentation remain in English.

Source changes do not replace an already built installer. The downloadable
v0.1.0 archive still contains the earlier UI until a new package is validated.

Settings → About shows the package version and GPL license, opens fixed help/issue
links and copies only version, browser/desktop runtime and language. It never
serializes account, repository, error or session objects.
